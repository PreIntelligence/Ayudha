using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using JuliaSharp;
using Avalonia.Interactivity;
using LiveChartsCore;
using System.Collections.ObjectModel;
using LiveChartsCore.SkiaSharpView;
using System.Reactive;

namespace AvaloniaAppJulia.ViewModels
{

  

    public class ViewModelBase : ReactiveObject
    {

       

        static Random _random = new Random();


double d = 0;// _random.NextDouble();

    }
}
